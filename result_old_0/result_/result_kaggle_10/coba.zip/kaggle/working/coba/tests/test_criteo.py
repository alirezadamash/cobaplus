from unittest import TestCase


class TestCountDict(TestCase):
    def test_basic(self) -> None:
        a = []
        pass
